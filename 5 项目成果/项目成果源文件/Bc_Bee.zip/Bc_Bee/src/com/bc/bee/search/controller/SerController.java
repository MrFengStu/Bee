package com.bc.bee.search.controller;

public class SerController {

}
