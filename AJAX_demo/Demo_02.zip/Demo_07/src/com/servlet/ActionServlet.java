package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class ActionServlet extends HttpServlet {
	public void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		String uri = request.getRequestURI();
		String action = uri.substring(uri.lastIndexOf("/"), uri.lastIndexOf("."));
		if (action.equals("/check_username")) {

			if (1 == 2) {
				throw new ServletException("");
			}
			String username = request.getParameter("username");
			if (username.equals("tom")) {
				out.println("�û�����ע��");
			} else {
				out.println("�û�������");
			}
		} else if (action.equals("/check_number")) {
			String number1 = request.getParameter("number");
			HttpSession session = request.getSession();
			String number2 = (String) session.getAttribute("number");
			if (number1.equalsIgnoreCase(number2)) {
				out.println("��֤����ȷ");
			} else {
				out.println("��֤�����");
			}
		}
		out.close();
	}
}
